from canvas import canvas

canvas.mainloop()